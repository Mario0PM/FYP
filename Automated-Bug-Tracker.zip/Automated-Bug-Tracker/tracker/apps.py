# Import the base AppConfig class from Django
from django.apps import AppConfig

# Define the app's configuration
class TrackerConfig(AppConfig):
    # Set the default type for automatically created primary keys
    default_auto_field = 'django.db.models.BigAutoField'
    
    # Name of the app (this should match the folder name)
    name = 'tracker'

    # This method runs when the app is ready (usually at startup)
    def ready(self):
        # Import the signals so they get registered properly
        import tracker.signals
