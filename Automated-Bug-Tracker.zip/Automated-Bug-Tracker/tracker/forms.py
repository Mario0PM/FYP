# Import Django's form tools and models
from django import forms
from .models import Bug, User
from django.contrib.auth.hashers import make_password  # To encrypt passwords

# Form for creating or updating bugs
class BugForm(forms.ModelForm):
    # Dropdown to choose an assignee, only active users are shown
    assignee = forms.ModelChoiceField(queryset=User.objects.filter(is_active=True), required=False)

    class Meta:
        model = Bug
        fields = ['title', 'description', 'severity', 'assignee', 'status']  # Fields shown in the form

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)  # Get the user using the form
        edit_mode = kwargs.pop('edit_mode', False)  # Check if it's being edited
        super().__init__(*args, **kwargs)

        # Hide the status field unless the form is in edit mode
        # and the user is either an Admin or Developer
        if not edit_mode or (user and user.role not in ['Admin', 'Developer']):
            self.fields.pop('status')


# Form for creating or editing users
class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'role']  # Shown fields
        widgets = {'password': forms.PasswordInput()}  # Hide password as it’s typed

    def save(self, commit=True):
        # Encrypt the password before saving
        user = super().save(commit=False)
        user.password = make_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user
