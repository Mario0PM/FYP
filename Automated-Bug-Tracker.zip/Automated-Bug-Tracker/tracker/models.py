# Import the base model classes from Django
from django.db import models

# Import Django's built-in user model base for customisation
from django.contrib.auth.models import AbstractUser

# Custom user model that includes a role field (e.g., admin, developer, tester)
class User(AbstractUser):
    role = models.CharField(max_length=50)  # Stores the user's role
    # You can add more fields here if needed
    pass

# Allows Django to swap this model as the user model if needed
class Meta:
    swappable = "AUTH_USER_MODEL"

# List of possible bug statuses shown as dropdown options in forms
STATUS_CHOICES = [
    ('Open', 'Open'),
    ('In Progress', 'In Progress'),
    ('Resolved', 'Resolved'),
    ('Closed', 'Closed'),
]

# Main model to store bug reports
class Bug(models.Model):
    title = models.CharField(max_length=200)  # Bug title
    description = models.TextField()  # Detailed description of the bug
    severity = models.CharField(max_length=50)  # How serious the bug is
    status = models.CharField(max_length=50, choices=STATUS_CHOICES)  # Bug status
    reporter = models.ForeignKey(User, related_name='reported_bugs', on_delete=models.CASCADE)  # Who reported it
    assignee = models.ForeignKey(User, related_name='assigned_bugs', on_delete=models.SET_NULL, null=True, blank=True)  # Who's fixing it
    created_at = models.DateTimeField(auto_now_add=True)  # When it was first reported
    updated_at = models.DateTimeField(auto_now=True)  # Last time it was updated
    fixed_code = models.TextField(blank=True, null=True)  # Final fixed version of the code (if available)

# Stores information about each auto-fix attempt
class FixLog(models.Model):
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE)  # Bug that was fixed
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)  # User who fixed it
    original_code = models.TextField()  # Code before fixing
    fixed_code = models.TextField()  # Code after auto-fixing
    issues_detected = models.TextField(blank=True, null=True)  # Problems found in the original code
    success = models.BooleanField(default=False)  # Whether the fix was successful
    timestamp = models.DateTimeField(auto_now_add=True)  # Time the fix was done
