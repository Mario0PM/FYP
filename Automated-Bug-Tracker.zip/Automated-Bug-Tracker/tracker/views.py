# Import the necessary modules and packages
import json
import tempfile
import subprocess
import autopep8
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_protect
from django.views.generic import ListView, CreateView, UpdateView
from django.urls import reverse_lazy
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import models
from django.db.models import Count, Q
from django.views.generic.detail import DetailView
from .models import Bug, User, STATUS_CHOICES, FixLog
from .forms import BugForm, UserForm
from datetime import datetime

# Get the current user model
User = get_user_model()

# Show a list of all reported bugs
class BugListView(ListView):
    model = Bug
    template_name = 'bug_management.html'
    context_object_name = 'bugs'

    # Only show specific fields, ordered by newest first
    def get_queryset(self):
        return Bug.objects.only("title", "severity", "status", "reporter", "assignee", "created_at").order_by('-created_at')

    # Add the current year to the page context
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['year'] = datetime.now().year
        return context

# Let users report a new bug
class BugCreateView(LoginRequiredMixin, CreateView):
    model = Bug
    form_class = BugForm
    template_name = 'bug_form.html'
    success_url = reverse_lazy('bug-list')

    # Pass extra info to the form
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        kwargs['edit_mode'] = False
        return kwargs

    # When form is valid, save the reporter and assign someone to fix it
    def form_valid(self, form):
        form.instance.reporter = self.request.user
        form.instance.assignee = auto_assign_user(form.instance.severity)
        form.instance.status = "Open"
        return super().form_valid(form)

# Let users update existing bugs
class BugUpdateView(UpdateView):
    model = Bug
    form_class = BugForm
    template_name = 'bug_form.html'
    success_url = reverse_lazy('bug-list')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        kwargs['edit_mode'] = True
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['users'] = User.objects.all()
        context['selected_bug'] = self.object
        return context

# Show details for one specific bug
class BugDetailView(DetailView):
    model = Bug
    template_name = 'bug_detail.html'
    context_object_name = 'bug'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        bug = self.get_object()

        # Get the most recent fix log
        latest_log = FixLog.objects.filter(bug=bug).order_by('-timestamp').first()

        context["uploaded_code"] = latest_log.original_code if latest_log else "No file uploaded yet."
        context["detected_issues"] = latest_log.issues_detected.splitlines() if latest_log and latest_log.issues_detected else []
        context["fixed_code"] = latest_log.fixed_code if latest_log else "No fixed version available."

        return context

# Delete a bug report
@login_required
def bug_delete(request, pk):
    bug = get_object_or_404(Bug, pk=pk)
    bug.delete()
    return redirect('bug-list')

# Show homepage with only open or in-progress bugs
@csrf_protect
def homepage_view(request):
    bugs = Bug.objects.filter(status__in=[choice[0] for choice in STATUS_CHOICES if choice[0] in ["Open", "In Progress"]]).order_by('-created_at')
    return render(request, "homepage.html", {"bugs": bugs})

# Handle user login
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('homepage')
        else:
            return render(request, "login.html", {"error": "Invalid username or password"})
    return render(request, "login.html")

# Handle user logout
def logout_view(request):
    logout(request)
    return redirect('login')

# Add a user to a group depending on their role
def assign_user_to_group(user, role):
    try:
        group = Group.objects.get(name=role)
        user.groups.add(group)
        user.save()
    except Group.DoesNotExist:
        pass

# View for managing all users
@login_required
def user_management_view(request):
    users = User.objects.all()
    return render(request, 'user_management.html', {'users': users})

# Create a new user
@login_required
def user_create_view(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user-management')
    else:
        form = UserForm()
    return render(request, 'user_form.html', {'form': form})

# Update an existing user (admin only)
@login_required
@user_passes_test(lambda u: u.is_staff)
def user_update_view(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            user = form.save(commit=False)
            if not request.user.is_staff:
                form.cleaned_data.pop("role", None)
            user.save()
            return redirect('user-management')
    else:
        form = UserForm(instance=user)
    return render(request, 'user_form.html', {'form': form})

# Delete a user
@login_required
def user_delete_view(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        user.delete()
        return redirect('user-management')
    return render(request, 'user_confirm_delete.html', {'user': user})

# Simple user area page
@login_required
def user_area(request):
    return render(request, 'user_area.html')

# Show the logged-in user's assigned bugs
@login_required
def user_area_view(request):
    assigned_bugs = Bug.objects.filter(assignee=request.user)
    return render(request, 'user_area.html', {'assigned_bugs': assigned_bugs})

# Handle auto-fixing bugs from uploaded code files
@login_required
def auto_fix_view(request, bug_id):
    bug = get_object_or_404(Bug, id=bug_id)

    if request.method == "POST":
        uploaded_file = request.FILES.get("code_input")

        if uploaded_file is None:
            messages.error(request, "No file was uploaded.")
            return redirect("my-area")

        file_content = uploaded_file.read()

        try:
            code = file_content.decode("utf-8")
        except AttributeError:
            code = str(file_content)

        if not code:
            return render(request, 'auto_fix_form.html', {
                'bug': bug,
                'error': "Uploaded file is empty or invalid. Please provide valid code."
            })

        original_code = code

        # Save code to temporary file
        with tempfile.NamedTemporaryFile(mode='w+', suffix='.py', delete=False) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        # Detect code issues using flake8
        result = subprocess.run(['flake8', temp_file_path], capture_output=True, text=True)
        issues = result.stdout

        # Fix code issues using autopep8
        fix_result = subprocess.run(['autopep8', '--aggressive', '--aggressive', temp_file_path], capture_output=True, text=True)
        fixed_code = fix_result.stdout

        # Save fix log to database
        FixLog.objects.create(
            bug=bug,
            user=request.user,
            original_code=original_code,
            fixed_code=fixed_code,
            issues_detected=issues,
            success=(issues.strip() == "")
        )

        return render(request, 'auto_fix_result.html', {
            'original_code': original_code,
            'fixed_code': fixed_code,
            'issues': issues,
            'bug': bug,
            'user': request.user,
        })

    return render(request, 'auto_fix_form.html', {'bug': bug})

# Accept the fixed code and update bug status
@login_required
def accept_fix(request, bug_id):
    bug = get_object_or_404(Bug, id=bug_id)

    if request.method == "POST":
        fixed_code = request.POST.get("fixed_code")
        bug.fixed_code = fixed_code
        bug.status = "Resolved"
        bug.save()
        return redirect('my-area')

# Automatically assign a developer based on who has the fewest open bugs
def auto_assign_user(severity):
    developers = User.objects.filter(role="Developer")
    developers = developers.annotate(active_bugs=Count('assigned_bugs', filter=models.Q(assigned_bugs__status__in=["Open", "In Progress"])))
    return developers.order_by('active_bugs').first()

# Show a list of all fix logs
@login_required
def fix_logs_view(request):
    logs = FixLog.objects.all().order_by('-timestamp')
    return render(request, 'fix_logs.html', {'fix_logs': logs})
