# Import the admin tools from Django
from django.contrib import admin

# Import the models you want to show in the admin site
from .models import User, Bug

# Import the default UserAdmin so we can customise it
from django.contrib.auth.admin import UserAdmin

# Create a custom version of the User admin
class CustomUserAdmin(UserAdmin):
    model = User

    # Fields to show in the list view (when looking at all users)
    list_display = ('username', 'email', 'role', 'is_staff', 'is_active')

    # Add the 'role' field to the default user detail form
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('role',)}),
    )

# Register the custom user admin so it appears in the admin dashboard
admin.site.register(User, CustomUserAdmin)
