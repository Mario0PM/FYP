# Import the signal that runs after database migrations
from django.db.models.signals import post_migrate

# Import the built-in Group and Permission models
from django.contrib.auth.models import Group, Permission

# Used to connect the function to the signal
from django.dispatch import receiver

# When all migrations are done, run this function
@receiver(post_migrate)
def create_user_groups(sender, **kwargs):
    # Define the user roles we want to create
    roles = ['admin', 'developer', 'tester']

    # Go through each role and create the group if it doesn't exist
    for role in roles:
        Group.objects.get_or_create(name=role)
