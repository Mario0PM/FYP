# Import the path function to define URL patterns
from django.urls import path

# Import the views we want to connect to URLs
from .views import BugListView, BugCreateView, BugUpdateView, bug_delete, create_bug_view

# Define the list of URL patterns for the app
urlpatterns = [
    # Show a list of all bugs
    path('bugs/', BugListView.as_view(), name='bug-list'),

    # Create a new bug report
    path('bug/create/', BugCreateView.as_view(), name='bug-create'),

    # Update a specific bug, using its ID
    path('bug/<int:pk>/update/', BugUpdateView.as_view(), name='bug-update'),

    # Delete a specific bug, using its ID
    path('bug/<int:pk>/delete/', bug_delete, name='bug-delete'),

    # (Optional) Another way to create a bug – if you’re using a function-based view
    path('create_bug/', create_bug_view, name='create_bug'),
]
